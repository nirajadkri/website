<?php
define('HTMLY', true);
$config_file = 'config/config.ini';
require 'system/vendor/autoload.php';
require 'system/htmly.php';