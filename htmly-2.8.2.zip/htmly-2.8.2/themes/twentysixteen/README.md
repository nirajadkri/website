# HTMLy Theme Twenty Sixteen
WordPress Twenty Sixteen ported to HTMLy.

## Installations 
 -  Upload and extract the zip file into themes directory.
 -  Rename the extracted folder to `twentysixteen`.
 -  Change the `views.root` using `http://www.example.com/admin/config` to `themes/twentysixteen`

## License

See the LICENSE.txt
