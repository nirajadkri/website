<?php if (!defined('HTMLY')) die('HTMLy'); ?>
<article class="page type-page hentry">
    <header class="entry-header">
        <h1 class="entry-title"><?php echo i18n('No_posts_found');?>!</h1>    
    </header><!-- .entry-header -->
</article><!-- #post-## -->